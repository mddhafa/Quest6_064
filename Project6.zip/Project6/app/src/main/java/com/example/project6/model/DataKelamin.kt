package com.example.project6.model

import com.example.project6.R

object DataKelamin {
    val listJK = listOf(
        R.string.laki,
        R.string.wanita
    )
}