package com.example.project6.model

data class DataMahasiswa(
    val nama : String = "",
    val gender : String = "",
    val alamat : String = "",
)
